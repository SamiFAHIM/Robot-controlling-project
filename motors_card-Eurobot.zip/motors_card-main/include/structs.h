
#ifndef STR_HPP
#define STR_HPP



typedef struct Odom {
   double  x;
   double y;
   double theta;
} Odom;  


#endif