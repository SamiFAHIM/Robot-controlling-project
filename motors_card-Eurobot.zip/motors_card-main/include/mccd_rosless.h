
#ifndef MCCD_ROSLESS_HPP
#define MCCD_ROSLESS_HPP

void init_mccd_rosless();

void start_mccd_rosless();

#endif