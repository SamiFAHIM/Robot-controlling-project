
#ifndef MCCD_HPP
#define MCCD_HPP

void init_mccd();

void start_mccd();

#endif